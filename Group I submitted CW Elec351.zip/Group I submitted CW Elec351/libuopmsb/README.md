# libuopmsb
Library to support the University of Plymouth Module Support Board

To test, rename the following:

main.cpp.txt to main.cpp 
mbed-os.lib.txt to mbed-os.lib
mbed_app.json.txt to mbed_app.json 