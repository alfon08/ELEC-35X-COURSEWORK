# To build the iothub_ll_telemetry_sample sample

Follow the instructions [here](../../../../../doc/get_started/mbed-freescale-k64f-c.md).